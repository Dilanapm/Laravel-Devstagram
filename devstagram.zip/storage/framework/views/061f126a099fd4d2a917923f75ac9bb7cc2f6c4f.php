<?php $__env->startSection('titulo'); ?>
    Perfil: <?php echo e($user->username); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <div class=" flex justify-center ">
        <div class=" w-full md:w-8/12 lg:w-6/12 flex flex-col items-center md:flex-row">
            <div class="w-8/12 lg:w-6/12 px-5">
                <img src="<?php echo e($user->imagen ? 
                asset('perfiles').'/'.$user->imagen :
                asset('img/usuario.svg')); ?>" alt="imagen de usuario">
            </div>
            <div class="md:w-8/12 lg:w-6/12 px-5 flex flex-col items-center md:justify-center md:items-start py-10">
                
                <div class="flex items-center gap-2">
                <p class="text-gray-700 text-2xl"><?php echo e($user->username); ?></p>
                
                <?php if(auth()->guard()->check()): ?>
                    <?php if($user->id === auth()->user()->id): ?>
                        <a href="<?php echo e(route('perfil.index')); ?>" 
                        class="text-gray-500 hover:text-gray-600 cursor-pointer">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L6.832 19.82a4.5 4.5 0 0 1-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 0 1 1.13-1.897L16.863 4.487Zm0 0L19.5 7.125" />
                              </svg>
                              
                        </a>
                    <?php endif; ?>
                <?php endif; ?>
                </div>
                <p class=" text-gray-800 text-sm mb-3 font-bold">
                    <?php echo e($user ->followers->count()); ?>

                    <span class=" font-normal"><?php echo app('translator')->choice('Seguidor|
                    Seguidores',$user ->followers->count()); ?></span>
                </p>
                <p class=" text-gray-800 text-sm mb-3 font-bold">
                    <?php echo e($user ->followings->count()); ?>

                    <span class=" font-normal">Seguiendo</span>
                </p>
                <p class=" text-gray-800 text-sm mb-3 font-bold">
                    <?php echo e($user->posts->count()); ?>

                    <span class=" font-normal">Posts</span>
                </p>
               <?php if(auth()->guard()->check()): ?>
                <?php if($user->id !== auth()->user()->id): ?>
                    <?php if($user->siguiendo(auth()->user())): ?>
                 
                        <form action="<?php echo e(route('users.unfollow', $user)); ?>" method="POST">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <input 
                            type="submit"
                            class="bg-red-500 text-white uppercase rounded-lg px-3 py-1 cursor-pointer font-bold text-xs"
                            value="Dejar de seguir"
                            >
                        </form>
                    <?php else: ?>
                        <form 
                        method="POST"
                        action="<?php echo e(route('users.follow', $user)); ?>" 
                        
                        >
                        <?php echo csrf_field(); ?>
                        <input 
                        type="submit"
                        class="bg-blue-500 text-white uppercase rounded-lg px-3 py-1 cursor-pointer font-bold text-xs"
                        value="seguir"
                        >
                        </form>
                    <?php endif; ?>
                <?php endif; ?>
               <?php endif; ?>
            </div>
            

            </p>
        </div>


    </div>
    <?php if (isset($component)) { $__componentOriginaldd88934e5f03a7cd5138c2e599754f366e7726c6 = $component; } ?>
<?php $component = App\View\Components\ListarPost::resolve(['posts' => $posts] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('listar-post'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ListarPost::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldd88934e5f03a7cd5138c2e599754f366e7726c6)): ?>
<?php $component = $__componentOriginaldd88934e5f03a7cd5138c2e599754f366e7726c6; ?>
<?php unset($__componentOriginaldd88934e5f03a7cd5138c2e599754f366e7726c6); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dilan/Laravel-Devstagram/resources/views/dashboard.blade.php ENDPATH**/ ?>