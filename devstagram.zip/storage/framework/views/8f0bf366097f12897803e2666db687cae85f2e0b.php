<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php echo $__env->yieldPushContent('styles'); ?>
        <title>Destagram - <?php echo $__env->yieldContent('titulo'); ?></title>
        <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
        <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
        <?php echo \Livewire\Livewire::styles(); ?>

    </head>
    <body class="bg-gray-100">
        <header class="p-5 border-b bg-white shadow">
            <div class="container mx-auto flex justify-between items-center">
                
                    <a href="<?php echo e(route('home')); ?>" class="text-3xl font-black">Devstagram</a>

                <?php if(auth()->guard()->check()): ?>  
                <nav class="flex gap-2 items-center">
                    <a class="flex items-center gap-2 bg-white border p-2 text-gray-600 rounded text-sm uppercase font-bold cursor-pointer"
                    href="<?php echo e(route('posts.create')); ?>">
                       <img class=" w-5" src="<?php echo e(asset('img/camara-reflex-digital.png')); ?>"> Crear
                    </a>
                    <a 
                    class=" font-bold text-gray-600 text-sm"
                    href="<?php echo e(route('posts.index',auth()->user()->username)); ?>">
                        Hola: <span class=" font-bold "><?php echo e(auth()->user()->username); ?></span>
                    </a>
                    
                    
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="font-bold uppercase text-gray-600 text-sm">
                            Cerrar sesion
                        </button>
                    </form>
                </nav> 
                <?php endif; ?>

                <?php if(auth()->guard()->guest()): ?>
                <nav class="flex gap-2 items-center">
                    <a class="font-bold uppercase text-gray-600 text-sm" href="<?php echo e(route('login')); ?>">Login</a>
                    <a class="font-bold uppercase text-gray-600 text-sm" href="<?php echo e(route('register')); ?>">Crear Cuenta</a>
                </nav> 
                <?php endif; ?>

                
            </div>
            
        </header>
        
        <main class=" container mx-auto mt-10">
            <h2 class="font-black text-center text-3xl mb-10">
                <?php echo $__env->yieldContent('titulo'); ?>
            </h2>
            <?php echo $__env->yieldContent('contenido'); ?>
        </main>
    <footer class="mt-10 text-center p-5 text-gray-500 font-bold uppercase">
        Devstagram - Todos los derechos reservados 
        <?php echo e(now()->year); ?>

    </footer>
    <?php echo \Livewire\Livewire::scripts(); ?>

    </body>
</html>
<?php /**PATH /home/dilan/Laravel-Devstagram/resources/views/layouts/app.blade.php ENDPATH**/ ?>